This package can be used to encode the string and then decode the encoded sting

import the package using pip install

use encode function to encode and decode function to decode

example 

variable = encode(string_to_be_encoded)